package com.exampledbhib.demodbhib.Controller;

import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.exampledbhib.demodbhib.Model.User;
import com.exampledbhib.demodbhib.service.userService;

@Controller
public class Register extends BaseController {
	@Autowired
	private userService service;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("userregister.jsp");
		return mv;
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView loginhereplease(@ModelAttribute("myuser") User usr) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("userid", usr.getStuUD());
		mv.addObject("username", usr.getStuName());
		LOGGER.info("this is an info message" + usr);
		LOGGER.warning("A warning message");
		// System.out.println(usr);
//	 	Configuration con = new Configuration().configure().addAnnotatedClass(User.class);
//	 	SessionFactory sf=con.buildSessionFactory();
//	 	Session session =sf.openSession();
//	 	Transaction tx=session.beginTransaction();
//	 	session.save(usr);
//	 	tx.commit();
		mv.setViewName("content.jsp");

		return mv;
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.POST)
	public ModelAndView loginhere(@ModelAttribute("myuser") User usr, BindingResult response) throws Exception {
		ModelAndView mv = new ModelAndView();
//	 	System.out.println(usr.toString());
//        System.out.println(response.hasErrors());
//        System.out.println(response.getAllErrors().toString());
//
//        if(response.hasErrors()){
//
//            List<String> errMessages = response.getAllErrors().stream().map(e->e.getDefaultMessage()).collect(Collectors.toList());
//            throw new Exception(errMessages.toString());
//        }
//        ModelAndView mv = new ModelAndView();
//        usr.setStuName(usr.getStuName().concat(service.getUsers()));
//
//	 	
//	 	boolean b =service.VerifyAge(usr.getStuAge());

		mv.setViewName("welcome.jsp");
		return mv;
	}

}
