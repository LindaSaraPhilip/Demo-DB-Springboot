package com.exampledbhib.demodbhib.Model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Table
@Entity
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String StuName;
	private String StuEmail;
	private int StuAge;
     private String Dept;
     private Date year;
	
	
	
	
	public Date getYear() {
		return year;
	}
	public void setYear(Date year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "User [StuName=" + StuName + ", StuEmail=" + StuEmail + ", StuAge=" + StuAge + ", Dept=" + Dept
				+ ", year=" + year + ", StuUD=" + StuUD + "]";
	}
	int StuUD;
	public String getStuName() {
		return StuName;
	}
	public void setStuName(String stuName) {
		StuName = stuName;
	}
	public String getStuEmail() {
		return StuEmail;
	}
	public void setStuEmail(String stuEmail) {
		StuEmail = stuEmail;
	}
	public int getStuAge() {
		return StuAge;
	}
	public void setStuAge(int stuAge) {
		StuAge = stuAge;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		Dept = dept;
	}
//	public int getYears() {
//		return years;
//	}
//	public void setYears(int year) {
//		this.years = years;
//	}
	public int getStuUD() {
		return StuUD;
	}
	public void setStuUD(int stuUD) {
		StuUD = stuUD;
	}


}