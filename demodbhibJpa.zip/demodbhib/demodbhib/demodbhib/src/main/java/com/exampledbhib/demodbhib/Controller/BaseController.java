package com.exampledbhib.demodbhib.Controller;

import java.util.logging.Logger;

import org.springframework.stereotype.Component;


@Component
public abstract class BaseController {
	final Logger LOGGER=Logger.getLogger(BaseController.class.getName());

}
