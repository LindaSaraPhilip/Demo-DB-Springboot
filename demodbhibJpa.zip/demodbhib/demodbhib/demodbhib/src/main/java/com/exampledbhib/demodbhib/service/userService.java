package com.exampledbhib.demodbhib.service;

import com.exampledbhib.demodbhib.Exceptions.NotAMajorAgeCustomerException;

public interface userService {
	public String getUsers();
    public boolean VerifyAge(int age) throws NotAMajorAgeCustomerException;

}
