package com.exampledbhib.demodbhib.service;

import org.springframework.stereotype.Service;

import com.exampledbhib.demodbhib.Exceptions.NotAMajorAgeCustomerException;
@Service
public class userserviceImpn implements userService {
	 @Override
	    public String getUsers() {
	        // TODO Auto-generated method stub
	       // int i = 10/0;
	        return "Linda";
	    }

	    @Override
	    public boolean VerifyAge(int age) throws NotAMajorAgeCustomerException {
	        // TODO Auto-generated method stub
	        if(age<18){
	            throw new NotAMajorAgeCustomerException("under age");
	            
	        }
	        return true;
	    }
}

