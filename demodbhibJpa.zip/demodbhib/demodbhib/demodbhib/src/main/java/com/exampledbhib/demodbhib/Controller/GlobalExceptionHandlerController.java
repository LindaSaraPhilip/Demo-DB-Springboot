package com.exampledbhib.demodbhib.Controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.exampledbhib.demodbhib.Exceptions.NotAMajorAgeCustomerException;
import com.exampledbhib.demodbhib.Exceptions.UserFieldException;



@ControllerAdvice
public class GlobalExceptionHandlerController {

	 @ExceptionHandler(value={UserFieldException.class,NotAMajorAgeCustomerException.class})
	    public ModelAndView handleAgeErrors(Exception ex){
	        ModelAndView mvError = new ModelAndView();
	        mvError.addObject("message", ex.getMessage());
	        mvError.setViewName("error.jsp");

	        ex.printStackTrace();
	        return mvError;
	    }
	    
	    @ExceptionHandler(Exception.class)
	    public ModelAndView handleRTErrors(Exception ex){
	        ModelAndView mvError = new ModelAndView();
	        mvError.addObject("message", "Oops! Something went wrong Try Again!!");
	        mvError.setViewName("error.jsp");
	        ex.printStackTrace();
	        return mvError;
	    }
	}