package com.exampledbhib.demodbhib.Exceptions;

public class NotAMajorAgeCustomerException extends Exception{
	public NotAMajorAgeCustomerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NotAMajorAgeCustomerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
