package com.exampledbhib.demodbhib.Model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Component;

@Component
@Table(name = "Student")
@Entity
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private	int StuUD;
	@Column(name="studentname",nullable=false)
	private String StuName;
	@Column(name="email",unique=true)
	private String StuEmail;
	private int StuAge;
	
    
	private String Dept;
     @Temporal(TemporalType.DATE)
     private Date year;
  
	public List<Login> getLogin() {
		return login;
	}
	public void setLogin(List<Login> login) {
		this.login = login;
	}
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="studid")
	private List<Login>login;
	
	
	
	
	public Date getYear() {
		return year;
	}
	public void setYear(Date year) {
		this.year = year;
	}
	

	
	
	@Override
	public  String toString() {
		return "User [StuUD=" + StuUD + ", StuName=" + StuName + ", StuEmail=" + StuEmail + ", StuAge=" + StuAge
				+ ", Dept=" + Dept + ", year=" + year + ", login=" + login + "]";
	}
	public String getStuName() {
		return StuName;
	}
	public void setStuName(String stuName) {
		StuName = stuName;
	}
	public String getStuEmail() {
		return StuEmail;
	}
	public void setStuEmail(String stuEmail) {
		StuEmail = stuEmail;
	}
	public int getStuAge() {
		return StuAge;
	}
	public void setStuAge(int stuAge) {
		StuAge = stuAge;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		Dept = dept;
	}
	
	public int getStuUD() {
		return StuUD;
	}
	public void setStuUD(int stuUD) {
		StuUD = stuUD;
	}


}