package com.exampledbhib.demodbhib.service;



import com.exampledbhib.demodbhib.Exceptions.NotAMajorAgeCustomerException;
import com.exampledbhib.demodbhib.Model.User;

public interface userService {
 public String getUsers();
 public boolean VerifyAge(int age) throws NotAMajorAgeCustomerException;
 public void save(User usr);
 public User fetchUserById(int stuUD);

}
