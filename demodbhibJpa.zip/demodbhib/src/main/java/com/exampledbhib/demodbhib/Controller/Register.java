package com.exampledbhib.demodbhib.Controller;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.exampledbhib.demodbhib.Model.Login;
import com.exampledbhib.demodbhib.Model.User;
import com.exampledbhib.demodbhib.service.userService;

@Controller
public class Register extends BaseController {
	@Autowired
	private userService service;
	

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("userregister.jsp");
		return mv;
	}
	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public ModelAndView loginafter() {
		ModelAndView mv = new ModelAndView();
		User usr=new User();
		
		mv.addObject("userid",usr.getStuUD());
		mv.addObject("username", usr.getStuName());

		mv.setViewName("userregister.jsp");
		return mv;
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView loginhereplease(@ModelAttribute("myuser") User usr) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("userid",usr.getStuUD());
		mv.addObject("username", usr.getStuName());
		LOGGER.info("this is an info message" + usr);
		LOGGER.warning("A warning message");
		 User usrr=new User();
	       usrr.setStuAge(usr.getStuAge());
	       usrr.setYear(usr.getYear());
	       usrr.setStuEmail(usr.getStuEmail());
	       usrr.setStuName(usr.getStuName());
	       usrr.setDept(usr.getDept());
	      
	       service.save(usrr);
		mv.setViewName("content.jsp");

		return mv;
	}
	@RequestMapping(value = "/contentshare", method = RequestMethod.GET)
	public ModelAndView contenthereplease() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("content.jsp");
		return mv;
	}
	@RequestMapping(value = "/contentshare", method = RequestMethod.POST)
	public ModelAndView contenthereplease(@ModelAttribute("myuser") User usr) {
		ModelAndView mv = new ModelAndView();
		  System.out.println(usr);
		mv.addObject("userid",usr.getStuUD());
		 mv.addObject("dep",usr.getDept());
	       mv.addObject("year",usr.getYear());
	       mv.addObject("ID",usr.getStuUD());
	       
	      
		mv.addObject("username", usr.getStuName());
		LOGGER.info("this is an info message" + usr);
		LOGGER.warning("A warning message");
		mv.addObject("username",usr.getStuName());
	      
		
		mv.setViewName("welcome.jsp");
		return mv;
	}
	@RequestMapping(value = "/welcomeshere", method = RequestMethod.GET)
	public ModelAndView loginherewhat()

	{
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("welcome.jsp");
		return mv;
	}

	
	 @RequestMapping(value="/welcomeshere",method=RequestMethod.POST)
	 public ModelAndView loginherepleases( @ModelAttribute("myuser1")User usr)
	{
 	ModelAndView mv = new ModelAndView();
 	System.out.println(usr);
	 	mv.addObject("username",usr.getStuName());
       mv.addObject("dep",usr.getDept());
     
			mv.setViewName("welcome.jsp");
			return mv;


}

}
