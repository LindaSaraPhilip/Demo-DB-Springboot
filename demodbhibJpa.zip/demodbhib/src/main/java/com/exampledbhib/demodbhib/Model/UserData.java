package com.exampledbhib.demodbhib.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

//@Entity
//@Table(name="userdata")
public class UserData {

/*	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String userid;
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	private String email;
	private String password;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="roleid")
	@JoinTable(
			name="user_role",
			joinColumns = {@JoinColumn(name="uid")},
			inverseJoinColumns = {@JoinColumn(name="rid")}
			)
	private List<Role> roles=new ArrayList<>();
	@Override
	public String toString() {
		return "UserData [userid=" + userid + ", email=" + email + ", password=" + password + ", roles=" + roles + "]";
	}
*/	
	
}
