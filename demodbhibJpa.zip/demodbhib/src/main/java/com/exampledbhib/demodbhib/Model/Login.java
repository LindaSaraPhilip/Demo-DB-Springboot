package com.exampledbhib.demodbhib.Model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Admin")
public class Login {

	@Id
	private String adminname;
	private String password;
	private String dep;
	
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="adminnames",referencedColumnName ="Adminname")
	private AdminDetails admin;
	public AdminDetails getAdmin() {
		return admin;
	}
	public void setAdmin(AdminDetails admin) {
		this.admin = admin;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Login [adminname=" + adminname + ", password=" + password + ", dep=" + dep + ", admin=" + admin + "]";
	}
	
}
