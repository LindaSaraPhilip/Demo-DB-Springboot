package com.exampledbhib.demodbhib.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="permempl")
public class permanentEmp extends Person {
	
	public String pnum;
	public String locn;
	@Override
	public String toString() {
		return "permanentEmp [pnum=" + pnum + ", locn=" + locn + "]";
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getLocn() {
		return locn;
	}
	public void setLocn(String locn) {
		this.locn = locn;
	}

}
