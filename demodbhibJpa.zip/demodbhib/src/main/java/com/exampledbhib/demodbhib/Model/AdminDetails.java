package com.exampledbhib.demodbhib.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class AdminDetails {
	@Id
	private String Adminname;
	private String AdminDep;
	public String getAdminname() {
		return Adminname;
	}
	public void setAdminname(String adminname) {
		Adminname = adminname;
	}
	
	public String getAdminDep() {
		return AdminDep;
	}
	public void setAdminDep(String adminDep) {
		AdminDep = adminDep;
	}
	@Override
	public String toString() {
		return "AdminDetails [Adminname=" + Adminname + ", AdminDep=" + AdminDep + "]";
	}
	
	

}
