package com.exampledbhib.demodbhib.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exampledbhib.demodbhib.Exceptions.NotAMajorAgeCustomerException;
import com.exampledbhib.demodbhib.Model.AdminDetails;
import com.exampledbhib.demodbhib.Model.Login;
import com.exampledbhib.demodbhib.Model.User;
import com.exampledbhib.demodbhib.repo.userdaoImpl;
@Service
@Transactional
public class userserviceImpn implements userService {
	@Autowired
	private userdaoImpl repo;
	
	 @Override
	    public String getUsers() {
	        // TODO Auto-generated method stub
	       // int i = 10/0;
	        return "Linda";
	    }

	    @Override
	    public boolean VerifyAge(int age) throws NotAMajorAgeCustomerException {
	        // TODO Auto-generated method stub
	        if(age<18){
	            throw new NotAMajorAgeCustomerException("under age");
	            
	        }
	        return true;
	    }

		@Override
		public void save(User usr) {
			// TODO Auto-generated method stub
//			List<Login> login=new ArrayList<>();
//			for(int i=0;i<5;i++)
//			{
//				AdminDetails atype=new AdminDetails();
//				if(i%2==0)
//				{
//					atype.setAdminDep("Computer Science");
//				}
//				else
//				{
//					atype.setAdminDep("Mechanical ");
//				}
//				Login l=new Login();
//				l.setAdminname("abcd"+i);
//				l.setDep(atype.getAdminDep());
//				login.add(l);
//			
//				
//			}
			
		repo.save(usr);
		}

		@Override
		public User fetchUserById(int stuUD) {
			
			return repo.getUserById(stuUD);
		}
}

