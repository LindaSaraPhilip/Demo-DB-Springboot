package com.exampledbhib.demodbhib.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.exampledbhib.demodbhib.Model.AdminDetails;
import com.exampledbhib.demodbhib.Model.Login;
import com.exampledbhib.demodbhib.Model.User;


@Controller
public class AdminController extends BaseController {
	@Autowired
	User usr;
	
	
	
	 @RequestMapping(value="/welcomes1",method=RequestMethod.GET)
	 public ModelAndView loginhere()
	 	{
	 	ModelAndView mv = new ModelAndView();
	 	mv.addObject("mylogin",new Login());
	 	
	 	mv.setViewName("admin.jsp");
	 	return mv;
	 	}
	 @RequestMapping(value="/welcomes1",method=RequestMethod.POST)
	 public ModelAndView loginhereplease( @ModelAttribute("mylogin")AdminDetails admindet)
 	{
	 	ModelAndView mv = new ModelAndView();
	 	System.out.println(admindet);
 		mv.addObject("username",admindet.getAdminname());
 		mv.addObject("userdept",admindet.getAdminDep());
	 	mv.setViewName("admindetails.jsp");
 	return mv;
	 	
	 	}
	

}
