package com.exampledbhib.demodbhib.Model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="contractemp")
public class ContractEmployee extends Person{
	public String vendorcode;
	public Date dateofexit;
	@Override
	public String toString() {
		return "ContractEmployee [vendorcode=" + vendorcode + ", dateofexit=" + dateofexit + "]";
	}
	public String getVendorcode() {
		return vendorcode;
	}
	public void setVendorcode(String vendorcode) {
		this.vendorcode = vendorcode;
	}
	public Date getDateofexit() {
		return dateofexit;
	}
	public void setDateofexit(Date dateofexit) {
		this.dateofexit = dateofexit;
	}
	

}
