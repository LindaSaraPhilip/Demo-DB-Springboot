package com.exampledbhib.demodbhib.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

//@Entity
//@Table(name="role")
public class Role {
/*	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String roleid;
	private String desc;
	

	@ManyToMany(targetEntity = UserData.class, mappedBy = "roles", cascade = CascadeType.ALL)
	private List<UserData> users=new ArrayList<>();

	public String getRoleid() {
		return roleid;
	}

	public void setRoleid(String roleid) {
		this.roleid = roleid;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<UserData> getUsers() {
		return users;
	}

	public void setUsers(List<UserData> users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "Role [roleid=" + roleid + ", desc=" + desc + ", users=" + users + "]";
	}
	*/


}
