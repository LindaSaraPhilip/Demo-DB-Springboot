package com.exampledbhib.demodbhib.repo;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import com.exampledbhib.demodbhib.Model.ContractEmployee;
import com.exampledbhib.demodbhib.Model.User;
import com.exampledbhib.demodbhib.Model.permanentEmp;

@Repository
public class userdaoImpl extends BaseDao {
	@Autowired
	private SessionFactory sFactory;
	
	
	public void save(User usr)
	{
		Session session = sFactory.getCurrentSession();
		session.save(usr);
	}
	public User getUserById(int StuUD)
	{
		Session session = sFactory.getCurrentSession();
		User usr=(User)session.get(User.class,StuUD);
		return usr;
	}
	
	public List<User> getUserByName(String value)
	{
		Session session=sFactory.getCurrentSession();
		Query query=session.createQuery("from User u where u.StuName like %:StuName%");
		query.setParameter(":StuName", value);
	((Criteria) query).setFetchSize(10);
		query.setFirstResult(1);
		//query.setMaxResults(21);
		return ((Criteria) query).list();
	}
	public List<User> getUsers()
	{
		Session session = sFactory.getCurrentSession();
		return session.createCriteria(User.class).list();
	}
}
