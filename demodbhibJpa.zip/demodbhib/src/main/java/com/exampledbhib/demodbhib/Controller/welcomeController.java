package com.exampledbhib.demodbhib.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.exampledbhib.demodbhib.Model.AdminDetails;
import com.exampledbhib.demodbhib.Model.User;
@Controller
public class welcomeController extends BaseController {

	/*@Autowired
	User usr;
	@RequestMapping(value = "/welcomeshere", method = RequestMethod.GET)
	public ModelAndView loginherewhat()

	{
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("welcome.jsp");
		return mv;
	}

	
	 @RequestMapping(value="/welcomeshere",method=RequestMethod.POST)
	 public ModelAndView loginhereplease( @ModelAttribute("myuser")User usr)
	{
 	ModelAndView mv = new ModelAndView();
 	System.out.println(usr);
	 	mv.addObject("username",usr.getStuName());
       mv.addObject("dep",usr.getDept());
     
			mv.setViewName("welcome.jsp");
			return mv;


}
*/

}
