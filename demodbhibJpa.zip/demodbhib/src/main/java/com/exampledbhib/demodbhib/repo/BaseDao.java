package com.exampledbhib.demodbhib.repo;

public abstract class BaseDao {

}
